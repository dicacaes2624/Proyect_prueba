package co.edu.usbcali.ws.rest.vo;

public class VOCalculadora {
	
	private int nuNumero1;
	private int nuNumero2;
	private int nuResultado;
	private String sbOperacion;
	private String sbProcesado;
	
	public int getNuNumero1() {
		return nuNumero1;
	}
	public void setNuNumero1(int nuNumero1) {
		this.nuNumero1 = nuNumero1;
	}
	public int getNuNumero2() {
		return nuNumero2;
	}
	public void setNuNumero2(int nuNumero2) {
		this.nuNumero2 = nuNumero2;
	}
	public int getNuResultado() {
		return nuResultado;
	}
	public void setNuResultado(int nuResultado) {
		this.nuResultado = nuResultado;
	}
	public String getSbOperacion() {
		return sbOperacion;
	}
	public void setSbOperacion(String sbOperacion) {
		this.sbOperacion = sbOperacion;
	}
	public String getSbProcesado() {
		return sbProcesado;
	}
	public void setSbProcesado(String sbProcesado) {
		this.sbProcesado = sbProcesado;
	}

	
}
