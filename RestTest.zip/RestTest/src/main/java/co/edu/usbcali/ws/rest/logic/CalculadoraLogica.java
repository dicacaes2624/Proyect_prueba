package co.edu.usbcali.ws.rest.logic;

public class CalculadoraLogica {
	
	public int suma(int nu1, int nu2){
		return nu1+nu2;
	}
	
	public int resta(int nu1, int nu2){
		return nu1-nu2;
	}
	
	public int multiplicacion(int nu1, int nu2){
		return nu1*nu2;
	}
	
	public int division(int nu1, int nu2){
		return nu1/nu2;
	}

}
